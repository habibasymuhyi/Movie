<?php 
  require 'koneksi.php';
  $id_film = $_GET['id_film'];
  $genre = mysqli_query($koneksi, "SELECT * FROM tb_genre ORDER BY nama_genre ASC LIMIT 0, 5");
  $film = mysqli_query($koneksi, "SELECT * FROM tb_film INNER JOIN tb_genre ON tb_film.id_genre = tb_genre.id_genre WHERE tb_film.id_film = '$id_film'");
  $komentar = mysqli_query($koneksi, "SELECT * FROM tb_komentar INNER JOIN tb_film ON tb_komentar.id_film = tb_film.id_film WHERE tb_komentar.id_film = '$id_film' ORDER BY tanggal_komentar DESC");
  $detail_film = mysqli_fetch_assoc($film);

  if (isset($_POST['btnTambahKomentar'])) {
    if (tambahKomentar($_POST) > 0) {
      setAlert("Berhasil dikirim", "Komentar berhasil dikirim", "success");
      header("Location: detail_film.php?id_film=$id_film");
    }
  }
?>

<!DOCTYPE html>
<html>
<head>
  <?php include 'include/css.php'; ?>
  <title>Detail Film: <?= $detail_film['nama_film']; ?></title>
</head>
<body style="">
  <?php include 'include/navbar.php'; ?>

  <div class="container px-4 rounded-bottom bg-dark">
    <div class="row mb-3 justify-content-center">
      <div class="col-lg">
        <h3>Watching: <?= $detail_film['nama_film']; ?></h3>
        <div class="embed-responsive embed-responsive-16by9">
          <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/D_RHCJazHoQ" allowfullscreen></iframe>
        </div>
      </div>
    </div>
    <div class="row my-2">
      <div class="col-lg">
        <div class="row my-2">
          <div class="col-lg">
            <h3>Title: <?= $detail_film['nama_film']; ?></h3>
          </div>
          
        </div>
        <h4>Deskripsi</h4>
        <p>Film ini sangat populer karena alur ceritanya yang menarik, akting para pemerannya yang memukau, serta sinematografi yang memanjakan mata. Ditambah lagi, film ini berhasil menyentuh emosi penonton dengan pesan yang mendalam dan musik latar yang mendukung suasana. Tak heran jika film ini mendapatkan banyak penghargaan dan pujian dari kritikus maupun penonton.</p>
      </div>
    </div>
    
  </div>

  
<?php include 'include/js.php'; ?>
</body>
</html>
