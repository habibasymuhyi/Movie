1. Menggunakan PHP version: 5.6.40
2. Database dengan nama streaming
3. Akses dengan direktori http://localhost/movie/streaming/
4. Klik Masuk sebagai admin, 
   Username : habib26
   Password : 11111111